import React from "react";

export default function MasterplanTitle(){
    return(
        <div className="grid grid-rows-2 justify-center content-center">
            <div className="flex-1">
                <p className="text-primary-dark text-center text-4xl font-black">
                    Masterplan
                </p>
                <p className="mt-2">
                    Haz clic sobre el lote de tu interés para mayor información.
                </p>
            </div>
        </div>
    );
}