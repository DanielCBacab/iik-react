import React from 'react';

// http://admin.iik-luumha.com/api/terrainapi

export default function TerrainList(){
    return (<div>Test</div>);
}