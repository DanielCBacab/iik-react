import React from "react";
import MasterplanTitle from "./MasterplanTitle";
import Financiamiento from "./Financiamiento";
import TerrainList from "./TerrainList";


export default function Masterplan(){
    return (
        <div className="grid grid-rows-3 mt-5 py-5" id="masterplan">
            <div className="flex-1">
               <MasterplanTitle/>
            </div>
            <div className="flex-1">
                <TerrainList/>
            </div>
            <div className="flex-1">
                <Financiamiento/>
            </div>
        </div>
    );
}